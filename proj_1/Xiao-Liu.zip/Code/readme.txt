Readme - encode

Checklist
    insertion_encoding.cpp
    makefile
    readme.txt (this file)

Step 1: Compile

    make encode

    and you will have an executable named 'encode' (it's the default if you don't specify with -o).

Step 2: Run

    ./encode insertion < input.txt

    and you will see some output on the screen.

    ./encode insertion < input.txt > output.txt

    and you will see some output in the newly generated 'output.txt'.


    
